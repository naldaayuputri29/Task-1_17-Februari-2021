package com.example.property_children

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
