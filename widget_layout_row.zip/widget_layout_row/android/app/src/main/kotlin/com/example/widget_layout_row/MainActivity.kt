package com.example.widget_layout_row

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
