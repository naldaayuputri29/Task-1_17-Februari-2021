package com.example.property_child

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
