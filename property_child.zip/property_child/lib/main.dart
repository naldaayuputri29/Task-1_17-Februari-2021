import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: MyHomePage()));
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Property Child"),
      ),
      body: Container(
        child: Text("Assalamu'alaikum Ukhti :)"),
        color: Colors.lightGreen,
        padding: EdgeInsets.all(16.0),
      ),
    );
  } }