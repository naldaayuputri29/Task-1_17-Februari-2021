package com.example.widget_layout_colum

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
