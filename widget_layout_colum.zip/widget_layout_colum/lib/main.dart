import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: MyHomePage()));
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Column"),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Container(
              child: Text("Assalamu'alaikum..."),
              color: Colors.orange,
              padding: EdgeInsets.all(16.0),
            ),
            Container(
              child: Text("Warahmatullahi..."),
              color: Colors.green,
              padding: EdgeInsets.all(16.0),
            ),
            Container(
              child: Text("Wabarakatuh...!"),
              color: Colors.pink,
              padding: EdgeInsets.all(16.0),
            ),
          ],
        ));
  } }